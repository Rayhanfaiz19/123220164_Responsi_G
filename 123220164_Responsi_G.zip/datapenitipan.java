@data penitipan
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package DAODataPenitipan;
import java.sql.*;
import java.util.*;
import connection.Connector;
import model.*;
import DAOImplement.DataPenitipanImplement;
import java.util.logging.Level;
import java.util.logging.Logger;

 
public class DataPenitipanDAO implements DataPenitipanImplement{
    Connection connection;
    
    final String getAllData = "select * from datapenitipan;";
    final String insertData = "INSERT INTO `dataPenitipan` (`namahewan`, `jenishewan`, `namapemilik`, `kontak`, `durasipenitipan`, `status`) VALUES (?, ?, ?, ?, ?, ?);";
    final String updateData = "UPDATE datapenitipan set namahewan=?, jenishewan=?, namapemilik=?, kontak=?, durasipenitipan=?, status=? where id=?;";
    final String deleteData = "DELETE from datapenitipan where id=?;";
    public DataPenginapanDAO(){
        connection = Connector.connection();
    }

    @Override
    public void insert(DataPenitipan dp) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insertData, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, dp.getNamaHewan());
            statement.setString(2, dp.getJenisHewan());
            statement.setString(3, dp.getNamaPemilik());
            statement.setInt(4, dp.getKontak());
            statement.setInt(5, dp.getDurasiPenitipan());
            statement.setString(6, dp.getStatus());
            statement.executeUpdate();
            ResultSet rs = statement.getGeneratedKeys();
            while(rs.next()){
                dp.setId(rs.getInt(1));
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void update(DataPenitipan dp) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(updateData);
            statement.setString(1, dp.getNamaHewan());
            statement.setString(2, dp.getJenisHewan());
            statement.setString(3, dp.getNamaPemilik());
            statement.setInt(4, dp.getKontak());
            statement.setInt(5, dp.getDurasiPenitipan());
            statement.setString(6, dp.getStatus());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void delete(int id) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(deleteData);
            statement.setInt(1, id);
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Penitipan> getAll() {
        List<DataPenitipan> dataPenitipan = null;
        try{
            dataPenitipan = new ArrayList<DataPenitipan>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(getAllData);
            while(rs.next()){
                DataPenitipan data = new DataPenitipan();
                data.setId(rs.getInt("nama hewan"));
                data.setNama(rs.getString("jenis hewan"));
                data.setKontak(rs.getString("nama pemilik"));
                data.setRuangan(rs.getString("kontak"));
                data.setDurasi(rs.getInt("durasi penitipan"));
                data.setHarga(rs.getInt("harga"));
                data.setStatus(rs.getString("status"));
                dataPenitipan.add(data);
            }
        }catch(SQLException ex){
            Logger.getLogger(DataPenitipanDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return dataPenitipan;
    }
}

